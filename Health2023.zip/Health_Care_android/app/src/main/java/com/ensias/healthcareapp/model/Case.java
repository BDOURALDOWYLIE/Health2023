package com.ensias.healthcareapp.model;

import java.util.Date;

public class Case {
    private String caseID;
    private Date dateCreation;

    public Case(String caseID, Date dateCreation) {
        this.caseID = caseID;
        this.dateCreation = dateCreation;
    }

    public String getDossierID() {
        return caseID;
    }

    public void setDossierID(String dossierID) {
        this.caseID = caseID;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }
}
