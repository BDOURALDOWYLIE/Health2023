package com.ensias.healthcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class FitchMedcain extends AppCompatActivity {
TextView t1,t2,t3,dyration,qyntity,time,year;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitch_medcain);
        t1=findViewById(R.id.textView2);
        t2=findViewById(R.id.textView4);
        t3=findViewById(R.id.textView5);
        dyration=findViewById(R.id.dyration);
        qyntity=findViewById(R.id.qyntity);
        time=findViewById(R.id.time);
        year=findViewById(R.id.year);

        t1.setText("Creation date "+getIntent().getStringExtra("dateCreated"));
        t2.setText("Email of dector "+getIntent().getStringExtra("doctor"));
        t3.setText("Name of Medcian "+getIntent().getStringExtra("description"));
        dyration.setText("the dyration "+getIntent().getStringExtra("dyration"));
        qyntity.setText("Number of times "+getIntent().getStringExtra("quntity"));
        time.setText("time of start madcian "+getIntent().getStringExtra("time"));
        year.setText("the year "+getIntent().getIntExtra("year",0));
    }
}