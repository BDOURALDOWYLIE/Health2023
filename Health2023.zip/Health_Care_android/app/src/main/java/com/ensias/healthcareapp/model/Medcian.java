package com.ensias.healthcareapp.model;

import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class Medcian {
    private String title;
    private String quentity;
    private String duration;
    private int month;
    private int day;
    private int year;
    private String time;
    private Date dateCreated;
    private String doctor;
public Medcian()
{

}
    public Medcian(String title, String quentity, String duration, int month, int day, int year, String time, Date dateCreated, String doctor) {
        this.title = title;
        this.quentity = quentity;
        this.duration = duration;
        this.month = month;
        this.day = day;
        this.year = year;
        this.time = time;
        this.dateCreated = dateCreated;
        this.doctor = doctor;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getQuentity() {
        return quentity;
    }

    public void setQuentity(String quentity) {
        this.quentity = quentity;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    @ServerTimestamp
    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }
}
