package com.ensias.healthcareapp.adapter;

public class AlarmAdabter {
}
