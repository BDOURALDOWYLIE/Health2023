package com.ensias.healthcareapp.adapter;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ensias.healthcareapp.Add_medcian_Alarm;
import com.ensias.healthcareapp.FicheInfo;
import com.ensias.healthcareapp.FitchMedcain;
import com.ensias.healthcareapp.MainActivity;
import com.ensias.healthcareapp.R;
import com.ensias.healthcareapp.model.Fiche;
import com.ensias.healthcareapp.model.Medcian;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class MedcianAdapter extends FirestoreRecyclerAdapter<Medcian,MedcianAdapter.FicheHolder> {
TextClock textClock;
Context context;
    public MedcianAdapter(@NonNull FirestoreRecyclerOptions<Medcian> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull MedcianAdapter.FicheHolder holder,  int position, @NonNull final Medcian model) {
        FirebaseFirestore.getInstance().document("Doctor/" + model.getDoctor()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                holder.doctor_name.setText(documentSnapshot.getString("name"));
            }
        });


        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("time to take your medcian");
        progressDialog.setMessage("Loading...");
        final Ringtone r = RingtoneManager.getRingtone(context.getApplicationContext(), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE));
        SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
        String currentDateandTime = sdf.format(new Date());
        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                if(currentDateandTime.equals(model.getTime())) {
                    r.play();
                    progressDialog.show();

                }
                else
                    {
                    r.stop();
                    progressDialog.dismiss();
                }
            }
        }, 0, 1000);

        //Toast.makeText(v.getContext().getApplicationContext(),currentDateandTime.toString(),Toast.LENGTH_LONG).show();
        // Toast.makeText(v.getContext().getApplicationContext(),model.getTime(),Toast.LENGTH_LONG).show();


        holder.type.setText(model.getTitle());
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), FitchMedcain.class);
                i.putExtra("dateCreated", model.getDateCreated().toString());
                i.putExtra("doctor",model.getDoctor());
                i.putExtra("description",model.getTitle());
                i.putExtra("time",model.getTime());
                i.putExtra("quntity",model.getQuentity());
                i.putExtra("dyration",model.getDuration());
                i.putExtra("year",model.getYear());
                v.getContext().startActivity(i);




           }
        });
        String[] date;
        if (model.getDateCreated() != null) {
            date = model.getDateCreated().toString().split(" ");
            // Thu Jun 04 14:46:12 GMT+01:00 2020
            holder.appointement_day_name.setText(date[0]);
            holder.appointement_day.setText(date[2]);
            holder.appointement_month.setText(date[1]);
            holder.doctor_view_title.setText(date[3]);
        }
    }



    private void openPage(Context wf, Fiche m){
        Intent i = new Intent(wf, FicheInfo.class);
        i.putExtra("dateCreated", m.getDateCreated().toString());
        i.putExtra("doctor",m.getDoctor());
        i.putExtra("description",m.getDescription());
        wf.startActivity(i);
    }



    @NonNull
    @Override
    public MedcianAdapter.FicheHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.alarm_dector_madcien_item,
                parent, false);
        context = parent.getContext();
        return new MedcianAdapter.FicheHolder(v);
    }
    class FicheHolder extends RecyclerView.ViewHolder {
        TextView doctor_name;
        TextView type;
        Button btn;
        TextView appointement_month;
        TextView appointement_day;
        TextView appointement_day_name;
        TextView doctor_view_title;

        public FicheHolder(View itemView) {
            super(itemView);
            doctor_name = itemView.findViewById(R.id.doctor_name);
            type = itemView.findViewById(R.id.type);
            btn = itemView.findViewById(R.id.voir_fiche_btn);
            appointement_month = itemView.findViewById(R.id.appointement_month);
            appointement_day = itemView.findViewById(R.id.appointement_day);
            appointement_day_name = itemView.findViewById(R.id.appointement_day_name);
            doctor_view_title = itemView.findViewById(R.id.doctor_view_title);
        }
    }
}
