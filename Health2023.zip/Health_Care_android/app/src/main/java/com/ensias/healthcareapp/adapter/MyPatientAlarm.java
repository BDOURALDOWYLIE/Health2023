package com.ensias.healthcareapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.ensias.healthcareapp.Add_medcian_Alarm;
import com.ensias.healthcareapp.ChatActivity;
import com.ensias.healthcareapp.DossierMedical;
import com.ensias.healthcareapp.R;
import com.ensias.healthcareapp.model.Patient;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class MyPatientAlarm  extends FirestoreRecyclerAdapter<Patient, MyPatientAlarm.MyPatientsHolder> {
        StorageReference pathReference ;


    public MyPatientAlarm(@NonNull FirestoreRecyclerOptions<Patient> options) {
        super(options);
    }


    @Override
protected void onBindViewHolder(@NonNull final MyPatientsHolder myPatientsHolder, int position, @NonNull final Patient patient) {
        myPatientsHolder.textViewTitle.setText(patient.getName());
        myPatientsHolder.textViewTelephone.setText("Tél : "+patient.getTel());
       myPatientsHolder.addAlarm.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               //Intent aa=new Intent(view.getContext(), Add_Medcian_alarm.class);
               Intent intent = new Intent(view.getContext(), Add_medcian_Alarm.class);
               intent.putExtra("patient_name", patient.getName());
               intent.putExtra("patient_email",patient.getEmail());
               intent.putExtra("patient_phone", patient.getTel());
               view.getContext().startActivity(intent);

           }
       });



        String imageId = patient.getEmail()+".jpg"; //add a title image
        pathReference = FirebaseStorage.getInstance().getReference().child("DoctorProfile/"+ imageId); //storage the image
        pathReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
@Override
public void onSuccess(Uri uri) {
        Picasso.with(myPatientsHolder.imageViewPatient.getContext())
        .load(uri)
        .placeholder(R.mipmap.ic_launcher)
        .fit()
        .centerCrop()
        .into(myPatientsHolder.imageViewPatient);//Image location

        // profileImage.setImageURI(uri);
        }
        }).addOnFailureListener(new OnFailureListener() {
@Override
public void onFailure(@NonNull Exception exception) {
        // Handle any errors
        }
        });


        }





@NonNull
@Override
public MyPatientsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_patinet_alarm_item, parent, false);
        return new MyPatientsHolder(v);
        }

class MyPatientsHolder extends RecyclerView.ViewHolder{
    //Here we hold the MyDoctorItems
    Button addAlarm;
    TextView textViewTitle;
    TextView textViewTelephone;
    ImageView imageViewPatient;

    RelativeLayout parentLayout;
    public MyPatientsHolder(@NonNull View itemView) {
        super(itemView);
        textViewTelephone = itemView.findViewById(R.id.text_view_telephone);
        textViewTitle = itemView.findViewById(R.id.patient_view_title);
         addAlarm= itemView.findViewById(R.id.add_new_alarm);
        imageViewPatient = itemView.findViewById(R.id.patient_item_image);


    }
}




}
